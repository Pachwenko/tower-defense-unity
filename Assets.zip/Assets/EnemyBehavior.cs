﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Should later be changed to abstract class.
/// A class to be inherited by every enemy. Does various functions in the game such as follows a predefined path and taking damage.
/// </summary>
public class EnemyBehavior : MonoBehaviour
{
    public float health;
    public float speed;

    // Use this for initialization
    void Start()
    {
        health = 6f;
        speed = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        var x = Input.GetAxis("Horizontal") * Time.deltaTime * 50.0f;
        var y = Input.GetAxis("Vertical") * Time.deltaTime * 50.0f;

        transform.Translate(x, y, 0);
    }


    public void ApplyDamage(float damage)
    {
        if (health - damage <= 0) {
            Destroy(gameObject);
        }
        health -= damage;
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Destroy(gameObject);
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        Debug.Log("shit on a waifu");
    }
}
