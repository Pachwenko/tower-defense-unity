﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class to be inherited by the Towers. Used to set various propertys and perhaps do some functions.
/// 
/// </summary>
public class TowerBehavior : MonoBehaviour
{
    public static float damage;

    // Use this for initialization
    void Start()
    {
        damage = 1.0f;
    }

    // Update is called once per frame
    void Update()
    {
        //print("I'm here");
    }


    void OnTriggerEnter2(Collider2D coll)
    {
        print("hello");
        //if (coll.gameObject.tag == "Enemy")
        Destroy(coll.gameObject);
        Destroy(gameObject);
        coll.gameObject.SetActive(false);
        coll.gameObject.SendMessage("ApplyDamage", 10.0f);

    }

    void OnTriggerStay2D(Collider2D coll)
    {
        print("hello");
        //if (coll.gameObject.tag == "Enemy")
        Destroy(coll.gameObject);
        coll.gameObject.SetActive(false);
        coll.gameObject.SendMessage("ApplyDamage", 10.0f);
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Destroy(gameObject);
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        Debug.Log("OnCollisionEnter2D");
    }
}
